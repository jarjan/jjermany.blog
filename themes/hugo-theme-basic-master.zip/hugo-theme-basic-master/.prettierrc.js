module.exports = {
  disableLanguages: ["html"]
};
