+++
title = "{{ replace .Name "-" " " | title }}"
date = {{ .Date }}
description = ""
tags = ["Development"]
categories = ["Development"]
download_url = "http://github.com/USERNAME/PROJECTNAME"
project_description = "DESC"
project_name = "PROJECTNAME"
project_url = "URL"
release_date = "DATE"
version = "0.0"
+++
